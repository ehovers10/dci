## ruby and speech acts

in ruby, everything is an object, and objects have attributes.

Attributes can be called, assigned, and inquired.

Assertions *call* an attribute, commands *assign*, and *questions* inquire.


