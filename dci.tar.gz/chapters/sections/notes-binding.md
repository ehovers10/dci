+ The bears discourse
+ Elements of its interpretation 
+ An information structure approach
  - Focus and question answer congruence
  - The issue of contrastive topic
  - Buering's solution
  - My concerns
  - Forward looking element
  - Accommodation reliance
+ A denial best approach
  - Contrast as representing correction
  - Layers and information annotating
  - Denial as downdate
  - My concerns
  - Binding problem
  - Downdate versus refinement
+ The importance of coherence
+ The conjecture/correction approach

Binding

Geurtz and Maier's LDRT avoids the binding problem by intermingling the layers. Information is indexed with its layer, but quantifiers can bind variables and conditions introduced into different layers at once.

But Spenader's issue is unique.  She is concerned with downdate, which involves removing information from a DRS and substituting in new information.  This substitution requires introducing new drefs, and thus, the binding problem arises anew.

Either this, or the theory will over generalize, unifying drefs where they should remain distinct.  EXAMPLES

Plausibility of keeping track of so many subscripts in the midst of discourse, but still having the ability to dispute earlier claims?  Something like a Kripke style problem with the Tarski truth level proposal for avoiding semantic paradox.

G&M problem: retraction can lead to unbinding of drefs

S&vL problem: treating denial as new DRS leads to binding problems

Layered DRT is an unstable equilibrium!
